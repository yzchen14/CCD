


<html> 
    
<header>
    <script src="jquery-3.6.0.min.js"></script>
    <script src="plotly-2.12.1.min.js"></script>

    <script src="side_table.js"></script>
  <link rel="stylesheet" href="plugins/bootstrap.css"> <!--宣告 CSS-->
  <script src="plugins/bootstrap.bundle.min.js"></script> <!--宣告 JS-->

</header>

<body>


<center><div id="myDiv"> </div></center>


</body>




</html>




<script>

var trace1 = {
  x: [0, 300, 0, 0, -300],
  y: [0, 0, -300, 300, 0],
  mode: 'markers',
  type: 'scatter'
};



var layout = {
  autosize: false,
  width: 480,
  height: 500,
 
  yaxis: {
    automargin: true,
  }, 
  xaxis: {
    automargin: true,
  },



  images: [
    {
      x: 0,
      y: -300,
      sizex: 600,
      sizey: 600,
      source: "img/circle.png",
      xanchor: "center",
      xref: "x",
      yanchor: "bottom",
      yref: "y", 
      layer: "below",
      xaxis: {range: [-400, 400]},
      yaxis: {range: [-400, 400]}
    }
  ]
};

var data = [trace1];

Plotly.newPlot('myDiv', data, layout);

</script>