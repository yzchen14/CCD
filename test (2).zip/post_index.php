<html>



</html>


<?php 
echo $_POST['firstName'];

?>

<script>


</script>