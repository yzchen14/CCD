

function generate_side_board(element_id){
    html_result = "";
    var board_arr = ["Test", "Test2"];
    for (let index = 0; index < board_arr.length; index++) {
        const element = board_arr[index];
        html_result = html_result + "<button id=" + element + ">"+ element + "</button>" + "<br>";
    }
    document.getElementById(element_id).innerHTML = html_result;
}


