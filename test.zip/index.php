


<html> 
    
<header>
    <script src="jquery-3.6.0.min.js"></script>
    <script src="plotly-2.12.1.min.js"></script>

    <script src="side_table.js"></script>
  <link rel="stylesheet" href="plugins/bootstrap.css"> <!--宣告 CSS-->
  <script src="plugins/bootstrap.bundle.min.js"></script> <!--宣告 JS-->

</header>

<body>

<form id = "testForm">
<div class="form-row">
<div class="col-md-4 mb-3">
<label for="validationDefault01">First name</label>
<input type="text" class="form-control" name = "firstName" id="validationDefault01" placeholder="First name" value="Mark" required>
</div>
<div class="col-md-4 mb-3">
<label for="validationDefault02">Last name</label>
<input type="text" class="form-control" name = "lastName" id="validationDefault02" placeholder="Last name" value="Otto" required>
</div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</body>




</html>




<script>


$.extend(
{
    redirectPost: function (location, args) {
        var form = $('<form>', { action: location, method: 'post' });
        $.each(args,
            function (key, value) {
                $(form).append(
                    $('<input>', { type: 'hidden', name: key, value: value })
                );
            });
        $(form).appendTo('body').submit();
    }
});


$("#testForm").submit(function(e) {
  var loginForm = $('#testForm').serializeArray();
  var loginFormObject = {};
  $.each(loginForm,
    function(i, v) {
        loginFormObject[v.name] = v.value;
    });
    $.redirectPost("post_index.php", loginFormObject);
    e.preventDefault();
  });

</script>