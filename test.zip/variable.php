<?php
$database_host = "host";
$database_user = "user";
$database_pass = "pass";
$database_name = "name";

?>